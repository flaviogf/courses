gatos = [{'idade': 6, 'nome': 'nina'}] 
